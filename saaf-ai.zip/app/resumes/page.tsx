'use client'

import { useState } from 'react'
import {
  BriefcaseBusiness,
  ChevronDown,
  FilePlus2,
  FileText,
  Gauge,
  Grid2X2,
  LayoutTemplate,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  Sparkles,
  Upload,
  X,
} from 'lucide-react'

const navItems = [
  { label: 'Jobs', icon: BriefcaseBusiness, href: '/dashboard' },
  { label: 'Kanban Board', icon: Grid2X2, href: '/kanban' },
  { label: 'Résumé', icon: FileText, href: '/resumes' },
  { label: 'Copilot Diagnostic', icon: Gauge, href: '/onboarding' },
  { label: 'Interview Prep', icon: MessageCircle, href: '#' },
]

const assets = [
  { icon: FilePlus2, title: 'New Resume', description: 'Craft and tailor to job description using AI.' },
  { icon: FileText, title: 'New Cover Note', description: 'Create and customize professional letters.' },
  { icon: LayoutTemplate, title: 'New Template', description: 'Create a reusable formatting layout.' },
  { icon: MessageCircle, title: 'Question Response', description: 'Generate tailored answers for application forms.' },
]

function Sidebar({ mobileOpen, setMobileOpen }: { mobileOpen: boolean; setMobileOpen: (open: boolean) => void }) {
  return <>
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-border bg-card px-4 py-5 transition-transform lg:static lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center justify-between px-3"><a href="/" className="flex items-center gap-2 text-lg font-semibold tracking-[-0.05em] text-primary"><span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground"><Sparkles className="size-4" /></span>Saaf AI</a><button className="rounded-lg p-2 text-muted-foreground lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation"><X className="size-5" /></button></div>
      <nav className="mt-10 space-y-1" aria-label="Primary navigation">{navItems.map(({ label, icon: Icon, href }) => <a key={label} href={href} onClick={() => setMobileOpen(false)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium ${label === 'Résumé' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:bg-secondary hover:text-primary'}`}><Icon className="size-[18px]" />{label}</a>)}</nav>
      <div className="mt-auto border-t border-border pt-4"><div className="flex items-center gap-3 px-3 py-3"><div className="flex size-9 items-center justify-center rounded-full bg-accent/15 text-sm font-bold text-accent">AK</div><div className="min-w-0"><p className="truncate text-sm font-semibold text-primary">Aarav Kapoor</p><p className="text-xs text-muted-foreground">Candidate profile</p></div></div><button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-primary"><Settings className="size-[18px]" />Settings</button></div>
    </aside>
    {mobileOpen && <button className="fixed inset-0 z-30 bg-primary/20 backdrop-blur-sm lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation overlay" />}
  </>
}

function DocumentsTable() {
  const [menuOpen, setMenuOpen] = useState<string | null>(null)
  const documents = [
    { name: 'Akshay_K_resume', tags: ['Uploaded', 'PDF', 'Default'], created: '9/5/26, 8:58 PM', edited: '9/5/26, 9:11 PM' },
    { name: 'Akshay_K_resume (Copy)', tags: ['Generated'], created: '9/5/26, 9:11 PM', edited: '9/5/26, 9:11 PM' },
  ]
  return <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"><div className="hidden grid-cols-[minmax(240px,1.5fr)_1fr_1fr_180px] gap-4 border-b border-border bg-secondary/45 px-5 py-3 text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground md:grid"><span>Resume name</span><span>Created</span><span>Last edited</span><span>Actions</span></div>{documents.map((document) => <div key={document.name} className="grid gap-4 border-b border-border px-5 py-5 last:border-b-0 md:grid-cols-[minmax(240px,1.5fr)_1fr_1fr_180px] md:items-center"><div><div className="flex items-center gap-2"><input type="checkbox" className="size-4 rounded border-border accent-[oklch(0.54_0.12_163)]" aria-label={`Select ${document.name}`} /><p className="text-sm font-semibold text-primary">{document.name}</p></div><div className="mt-2 flex flex-wrap gap-1.5 pl-6">{document.tags.map((tag) => <span key={tag} className={`rounded-md px-2 py-1 text-[10px] font-semibold ${tag === 'Default' ? 'bg-accent/10 text-accent' : 'bg-secondary text-muted-foreground'}`}>{tag}</span>)}</div></div><div className="pl-6 text-xs text-muted-foreground md:pl-0"><span className="mr-2 font-semibold uppercase tracking-wide text-[10px] md:hidden">Created</span>{document.created}</div><div className="pl-6 text-xs text-muted-foreground md:pl-0"><span className="mr-2 font-semibold uppercase tracking-wide text-[10px] md:hidden">Last edited</span>{document.edited}</div><div className="flex items-center gap-2 pl-6 md:pl-0"><button className="rounded-lg border border-border px-3 py-2 text-xs font-semibold text-primary hover:bg-secondary">Edit</button><div className="relative"><button onClick={() => setMenuOpen(menuOpen === document.name ? null : document.name)} className="flex items-center gap-1 rounded-lg px-2 py-2 text-xs font-semibold text-muted-foreground hover:bg-secondary hover:text-primary">More <ChevronDown className="size-3.5" /></button>{menuOpen === document.name && <div className="absolute right-0 top-9 z-20 min-w-32 rounded-xl border border-border bg-card p-1 shadow-lg"><button className="w-full rounded-lg px-3 py-2 text-left text-xs hover:bg-secondary">Duplicate</button><button className="w-full rounded-lg px-3 py-2 text-left text-xs text-destructive hover:bg-secondary">Delete</button></div>}</div></div></div>)}</div>
}

export default function ResumesPage() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [activeTab, setActiveTab] = useState('Resumes')
  return <main className="min-h-screen bg-background text-foreground"><div className="flex min-h-screen"><Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} /><div className="min-w-0 flex-1"><header className="flex h-20 items-center justify-between border-b border-border bg-card px-5 sm:px-8"><div className="flex items-center gap-3"><button className="rounded-xl border border-border p-2 text-primary lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu className="size-5" /></button><div><p className="text-[11px] font-bold uppercase tracking-[0.2em] text-accent">Your workspace</p><h1 className="text-2xl font-semibold tracking-[-0.06em] text-primary">Résumé</h1></div></div><div className="flex items-center gap-2"><button className="rounded-xl p-2.5 text-muted-foreground hover:bg-secondary" aria-label="Search"><Search className="size-5" /></button><div className="ml-1 flex size-9 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">AK</div></div></header><div className="mx-auto max-w-[1500px] p-5 sm:p-8"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="text-[11px] font-bold uppercase tracking-[0.2em] text-accent">Career library</p><h2 className="mt-2 text-3xl font-semibold tracking-[-0.07em] text-primary sm:text-4xl">My Documents</h2><p className="mt-2 text-sm text-muted-foreground">Manage, parse, and tailor all of your career documents here.</p></div><button className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-semibold text-accent-foreground shadow-sm hover:bg-accent/90"><Upload className="size-4" />Upload</button></div><div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{assets.map(({ icon: Icon, title, description }) => <button key={title} className="group relative flex min-h-36 flex-col items-start rounded-2xl border border-border bg-card p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-md"><span className="flex size-10 items-center justify-center rounded-xl bg-accent/10 text-accent"><Icon className="size-5" /></span><span className="mt-4 text-sm font-semibold text-primary">{title}</span><span className="mt-1 max-w-[230px] text-xs leading-5 text-muted-foreground">{description}</span><Plus className="absolute right-4 top-4 size-4 text-muted-foreground transition group-hover:text-accent" /></button>)}</div><div className="mt-10 flex gap-6 border-b border-border">{['Resumes', 'Cover Letters', 'Templates'].map((tab) => <button key={tab} onClick={() => setActiveTab(tab)} className={`border-b-2 px-1 pb-4 text-sm font-semibold ${activeTab === tab ? 'border-accent text-primary' : 'border-transparent text-muted-foreground hover:text-primary'}`}>{tab}</button>)}</div><div className="flex flex-col gap-4 py-5 lg:flex-row lg:items-center lg:justify-between"><div className="flex items-center gap-3"><span className="text-sm text-muted-foreground">0 selected</span><button disabled className="rounded-lg border border-border px-3 py-2 text-xs font-semibold text-muted-foreground opacity-50">Delete</button></div><div className="flex flex-col gap-2 sm:flex-row"><button className="inline-flex items-center justify-center gap-2 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-accent-foreground hover:bg-accent/90"><Upload className="size-3.5" />Upload</button><button className="inline-flex items-center justify-between gap-5 rounded-lg border border-border bg-card px-3.5 py-2 text-xs font-semibold text-muted-foreground hover:text-primary">All <ChevronDown className="size-3.5" /></button><label className="flex items-center gap-2 rounded-lg border border-border bg-card px-3.5 py-2 text-xs text-muted-foreground"><Search className="size-3.5" /><input className="w-full bg-transparent outline-none placeholder:text-muted-foreground/70 sm:w-44" placeholder="Search documents..." /></label></div></div><DocumentsTable /></div></div></div></main>
}
