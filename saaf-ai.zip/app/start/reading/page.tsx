'use client'

import { useEffect, useState } from 'react'
import { Check, FileText, LockKeyhole, ShieldCheck } from 'lucide-react'

const steps = [
  { title: 'Reading your resume', detail: 'Pulling out title, employer, city, skills and industry.', icon: FileText },
  { title: 'Removing direct identifiers', detail: 'Stripping your email, phone and profile links before anything leaves our server.', icon: LockKeyhole },
  { title: 'Matching today\'s roles', detail: 'Comparing your profile against the roles indexed today.', icon: ShieldCheck },
  { title: 'Scoring each role', detail: 'Checking role match, experience, skills, location, work mode and credential.', icon: FileText },
  { title: 'Sorting your shortlist', detail: 'Grouping roles into matches you, experience out of range, location out of range and worth a look.', icon: Check },
]

export default function ReadingPage() {
  const [completed, setCompleted] = useState(0)
  const [isSlow, setIsSlow] = useState(false)

  useEffect(() => {
    const progressTimer = window.setInterval(() => setCompleted((current) => Math.min(current + 1, steps.length)), 1500)
    const slowTimer = window.setTimeout(() => setIsSlow(true), 6000)
    return () => {
      window.clearInterval(progressTimer)
      window.clearTimeout(slowTimer)
    }
  }, [])

  const currentStep = Math.min(completed, steps.length - 1)
  const isComplete = completed === steps.length

  return (
    <main className="min-h-screen bg-background px-5 py-6 text-foreground sm:px-8 sm:py-10">
      <div className="mx-auto flex min-h-[calc(100vh-3rem)] max-w-3xl flex-col justify-center sm:min-h-[calc(100vh-5rem)]">
        <header className="mb-10 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2 text-sm font-semibold tracking-[-0.03em] text-primary" aria-label="Saaf AI home"><span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground"><span className="text-xs">S</span></span>Saaf AI</a>
          <span className="rounded-full border border-border bg-card px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Resume reading</span>
        </header>

        <section className="rounded-[0.8rem] border border-border bg-card p-6 shadow-sm sm:p-10">
          <div className="max-w-xl"><p className="text-xs font-bold uppercase tracking-[0.18em] text-accent">What is actually happening</p><h1 className="mt-3 text-balance text-3xl font-semibold leading-tight tracking-[-0.06em] text-primary sm:text-4xl">We&apos;re building your first shortlist, carefully.</h1><p className="mt-4 text-sm leading-6 text-muted-foreground sm:text-base">We show our working because a career match should be checkable. No invented progress percentage, just the steps we&apos;re taking with your file.</p></div>
          <div className="mt-9 border-t border-border pt-2" aria-live="polite">
            {steps.map((step, index) => { const Icon = step.icon; const done = index < completed; const current = index === currentStep && !done && !isComplete; return <div key={step.title} className={`relative flex gap-4 border-b border-border py-5 last:border-b-0 ${current ? 'text-primary' : 'text-muted-foreground'}`}><div className={`relative z-10 flex size-9 shrink-0 items-center justify-center rounded-full border ${done ? 'border-accent bg-accent text-accent-foreground' : current ? 'border-accent bg-accent/10 text-accent' : 'border-border bg-secondary text-muted-foreground'}`}>{done ? <Check className="size-4" /> : <Icon className={`size-4 ${current ? 'animate-pulse' : ''}`} />}</div><div className="min-w-0 pt-0.5"><p className={`text-sm font-semibold ${done || current ? 'text-primary' : 'text-muted-foreground'}`}>{step.title}{current && <span className="ml-2 text-[10px] font-bold uppercase tracking-[0.14em] text-accent">Now</span>}</p><p className="mt-1 text-xs leading-5 text-muted-foreground sm:text-sm">{step.detail}</p></div></div> })}
          </div>
          <div className="mt-7 rounded-[0.8rem] bg-secondary/60 px-4 py-3.5"><p className="flex items-start gap-2 text-xs leading-5 text-muted-foreground"><ShieldCheck className="mt-0.5 size-4 shrink-0 text-accent" />Your file is deleted the moment parsing finishes. Only fields you confirm are stored.</p></div>
          <p className="mt-5 text-center text-xs leading-5 text-muted-foreground" role="status">{isComplete ? 'Your shortlist is ready to review.' : isSlow ? 'This is taking longer than expected. We&apos;re still working through your file; you can safely leave this tab open.' : "This usually takes a few moments. We'll be exact before we are fast."}</p>
        </section>
      </div>
    </main>
  )
}
