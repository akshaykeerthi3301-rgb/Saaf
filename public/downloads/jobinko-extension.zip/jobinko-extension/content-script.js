/**
 * Jobinko extension — the side panel on a job page: match, autofill, save, tailor.
 *
 * ⚠️ THE PANEL ACTS ON THE PERSON'S OWN ACCOUNT, AND ONLY WHEN THEY ASK. It reads the page (extractor.js), asks the
 * service worker to score it and to talk to Jobinko with the person's login, and draws the result. The only writes to
 * the host page are the form fills the person asks for (autofill.js). No submitting, no navigating.
 *
 * ⚠️ THE PANEL LIVES IN A SHADOW ROOT, AND THAT IS NOT OPTIONAL. It renders on sites with arbitrary CSS; style bleeding
 * in either direction is both the commonest cause of a broken-looking panel and of a store-review rejection.
 * `:host { all: initial }` resets anything inherited.
 *
 * ⚠️ EVERY STRING FROM THE PAGE OR THE SERVER IS ESCAPED BEFORE innerHTML. A posting containing markup would otherwise
 * render inside our panel, on their page.
 */
const SITE = 'https://jobinko.in'

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

/** Same page, ignoring query and hash — how the tracker and this panel agree a job is "this one". */
const pageKey = (u) => { try { const x = new URL(u); return x.origin + x.pathname.replace(/\/+$/, '') } catch { return u } }

const STAGE_LABEL = { saved: 'Saved', applying: 'Applying', applied: 'Applied', interviewing: 'Interviewing', offer: 'Offer', rejected: 'Rejected', closed: 'Archived' }

/**
 * The palette is copied from the app's `.dark` block in src/app/globals.css. An extension cannot load the app's
 * stylesheet, so these are the one place those tokens are restated — change them together. Score bands follow
 * src/lib/score-bands.ts: green from 75, amber from 60, red below.
 */
const STYLE = `
  :host { all: initial }
  * { box-sizing: border-box }
  /* Colours shared by the panel and the pop-ups. LAYOUT must NOT be shared: the pop-up once inherited the panel's 380px width. */
  .panel, .afm { --bg: oklch(0.205 0.006 285.885); --fg: oklch(0.985 0 0); --muted: oklch(0.705 0.015 286.067);
    --line: oklch(1 0 0 / 10%); --chip: oklch(0.274 0.006 286.033); --brand: oklch(0.585 0.233 277.117);
    --brand-2: oklch(0.558 0.288 302.321); --accent: oklch(0.673 0.182 276.935);
    --high: oklch(0.765 0.177 163.223); --mid: oklch(0.828 0.189 84.429); --low: oklch(0.704 0.191 22.216); }
  .panel {
    position: fixed; top: 0; right: 0; height: 100vh; width: 380px; max-width: 94vw; display: flex; flex-direction: column;
    font: 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: var(--fg); background: var(--bg);
    border-left: 1px solid var(--line); box-shadow: -12px 0 40px oklch(0 0 0 / 40%) }
  .panel[hidden] { display: none }
  /* The "Your Autofill information" pop-up — the same layout as Jobright's (section list left, pane right, Update below),
     drawn with Jobinko's colours. */
  .afm { position: fixed; inset: 0; z-index: 20; display: flex; align-items: center; justify-content: center; background: oklch(0 0 0 / 60%);
    font: 14px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: var(--fg) }
  .afm-card { width: min(1056px, 94vw); height: min(672px, 92vh); display: flex; flex-direction: column; border-radius: 24px; background: var(--bg);
    border: 1px solid var(--line); box-shadow: 0 24px 80px oklch(0 0 0 / 55%); overflow: hidden }
  .afm-head { display: flex; align-items: center; justify-content: space-between; padding: 22px 28px 14px }
  .afm-head h2 { margin: 0; font-size: 20px; font-weight: 700 }
  .afm-x { all: unset; cursor: pointer; color: var(--muted); font-size: 20px; padding: 4px 8px; border-radius: 8px }
  .afm-x:hover { background: var(--chip); color: var(--fg) }
  .afm-banner { display: flex; gap: 12px; align-items: flex-start; margin: 0 0 0; padding: 14px 28px; background: var(--chip); font-size: 13px }
  .afm-banner b { display: block; font-size: 14px }
  .afm-banner span { color: var(--muted) }
  .afm-i { flex: none; width: 18px; height: 18px; border-radius: 99px; background: var(--fg); color: var(--bg); font-size: 12px; font-weight: 700; display: grid; place-items: center; margin-top: 2px }
  .afm-body { flex: 1; min-height: 0; display: flex }
  .afm-nav { width: 270px; flex: none; padding: 22px 22px; display: flex; flex-direction: column; gap: 6px; border-right: 1px solid var(--line); overflow-y: auto }
  .afm-nav button { all: unset; cursor: pointer; padding: 11px 14px; border-radius: 14px; font-size: 15px; font-weight: 600; color: var(--fg); border: 1px solid transparent }
  .afm-nav button:hover { background: var(--chip) }
  .afm-nav button.on { background: var(--chip); border-color: oklch(0.673 0.182 276.935 / 55%) }
  .afm-pane { flex: 1; min-width: 0; padding: 22px 32px; overflow-y: auto }
  .afm-pane h3 { margin: 0 0 6px; font-size: 24px; font-weight: 700 }
  .afm-sub { margin: 0 0 14px; color: var(--muted); font-size: 14px }
  .afm-sub b { color: var(--fg) }
  .afm-pane hr { border: 0; border-top: 1px solid var(--line); margin: 16px 0 }
  .afm-pane label.afm-l { display: block; margin: 14px 0 6px; font-weight: 600; font-size: 14px }
  .afm-in { width: 100%; padding: 12px 14px; border-radius: 12px; border: 1px solid var(--line); background: var(--chip); color: var(--fg); font: inherit; outline: none }
  .afm-in:focus { border-color: var(--accent) }
  .afm-in[readonly] { color: var(--muted) }
  .afm-pw { position: relative }
  .afm-pw .afm-in { padding-right: 44px }
  .afm-eye { all: unset; cursor: pointer; position: absolute; right: 12px; top: 11px; color: var(--muted); font-size: 16px }
  .afm-rules { list-style: none; padding: 0; margin: 10px 0 0; display: grid; gap: 8px; font-size: 14px }
  .afm-rules li { display: flex; align-items: center; gap: 10px }
  .afm-rules i { width: 16px; height: 16px; border-radius: 99px; border: 1.5px solid var(--muted); flex: none; display: grid; place-items: center; font-style: normal; font-size: 10px; color: transparent }
  .afm-rules li.ok i { background: var(--high); border-color: var(--high); color: var(--bg) }
  .afm-green { display: flex; gap: 10px; align-items: center; padding: 12px 16px; border-radius: 12px; background: oklch(0.765 0.177 163.223 / 14%); color: var(--fg); font-size: 14px }
  .afm-row { display: flex; gap: 10px; align-items: flex-start; font-size: 14px; margin: 0 0 14px }
  .afm-row input { margin-top: 4px }
  .afm-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 14px 18px }
  .afm-grid .afm-l { margin: 0 0 6px }
  .afm-foot { padding: 14px 28px 20px; border-top: 1px solid var(--line); display: flex; justify-content: center }
  .afm-update { all: unset; cursor: pointer; width: 240px; text-align: center; padding: 13px 0; border-radius: 999px; font-weight: 700; font-size: 16px;
    background: linear-gradient(135deg, var(--brand), var(--brand-2)); color: #fff }
  .afm-update[disabled] { cursor: default; background: var(--chip); color: var(--muted) }
  .afm-note { margin-top: 12px; font-size: 13px; color: var(--muted) }
  .afm-pane a { color: var(--accent) }
  .afm-paper { background: #fff; color: #111; border-radius: 10px; padding: 22px 26px; font: 11.5px/1.5 Georgia, 'Times New Roman', serif; white-space: pre-wrap; overflow-wrap: anywhere }
  .afm-split { display: flex; flex: 1; min-height: 0 }
  .afm-list { width: 360px; flex: none; padding: 22px; border-right: 1px solid var(--line); overflow-y: auto }
  .afm-list h4 { margin: 0 0 10px; font-size: 14px }
  .afm-opt { display: flex; align-items: center; gap: 10px; padding: 11px 12px; border-radius: 12px; background: var(--chip); margin-bottom: 8px; cursor: pointer; font-size: 14px; border: 1px solid transparent }
  .afm-opt.on { border-color: oklch(0.673 0.182 276.935 / 55%) }
  .afm-opt .nm { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
  .afm-badge { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 99px; background: oklch(0.765 0.177 163.223 / 20%); color: var(--high) }
  .afm-foot2 { padding: 14px 28px 20px; border-top: 1px solid var(--line); display: flex; justify-content: center; gap: 14px }
  .afm-ghost { all: unset; cursor: pointer; padding: 12px 22px; border-radius: 999px; border: 1px solid var(--line); font-weight: 700; font-size: 15px }
  .afm-chips { display: flex; flex-wrap: wrap; gap: 8px }
  .afm-chips span { background: var(--chip); border: 1px solid var(--line); border-radius: 8px; padding: 6px 10px; font-size: 13px }
  .afm-card2 { background: var(--chip); border: 1px solid var(--line); border-radius: 14px; padding: 14px 16px; margin-bottom: 12px }
  .afm-card2 h4 { margin: 0 0 8px; font-size: 16px }
  .sv { position: absolute; inset: 0; z-index: 6; background: var(--bg); display: flex; flex-direction: column }
  .sv[hidden] { display: none }
  .svh { display: flex; align-items: center; gap: 10px; padding: 14px; border-bottom: 1px solid var(--line); font-size: 15px }
  .svb { flex: 1; overflow-y: auto; padding: 14px }
  .svb h4 { margin: 14px 0 8px; font-size: 14px }
  .svr { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; background: var(--chip); margin-bottom: 8px; cursor: pointer }
  .svf { padding: 12px 14px; border-top: 1px solid var(--line) }

  .panel.left { right: auto; left: 0; border-left: 0; border-right: 1px solid var(--line); box-shadow: 12px 0 40px oklch(0 0 0 / 40%) }
  header { display: flex; align-items: center; gap: 8px; padding: 12px 14px; border-bottom: 1px solid var(--line) }
  .brand { font-weight: 700; font-size: 15px; background: linear-gradient(135deg, var(--accent), var(--brand-2));
    -webkit-background-clip: text; background-clip: text; color: transparent }
  .badge { font-size: 10px; padding: 2px 8px; border-radius: 999px; background: var(--chip); color: var(--muted) }
  .grow { flex: 1 }
  .x { all: unset; cursor: pointer; color: var(--muted); font-size: 18px; line-height: 1; padding: 2px 6px; border-radius: 6px }
  .x:hover { background: var(--chip); color: var(--fg) }
  .scroll { flex: 1; overflow-y: auto; padding: 12px 14px 20px }
  section { margin-bottom: 12px }
  .box { background: var(--chip); border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px }
  .muted { color: var(--muted); font-size: 11px }
  .bar { height: 6px; border-radius: 999px; background: var(--chip); overflow: hidden }
  .bar > i { display: block; height: 100%; border-radius: 999px; background: linear-gradient(90deg, var(--brand), var(--brand-2)); transition: width .3s }
  .support { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;
    background: oklch(0.765 0.177 163.223 / 14%); color: var(--high) }
  .support.off { background: var(--chip); color: var(--muted); font-weight: 500 }
  .dot { width: 8px; height: 8px; border-radius: 99px; background: currentColor; flex: none }
  .head { display: flex; gap: 12px; align-items: center }
  .ring { width: 58px; height: 58px; flex: none; position: relative }
  .ring svg { transform: rotate(-90deg) }
  .ring b { position: absolute; inset: 0; display: grid; place-items: center; font-size: 17px; font-variant-numeric: tabular-nums }
  .job { min-width: 0 }
  .job .t { font-weight: 600; font-size: 14px; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical }
  .chips { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-top: 10px }
  .chip { background: var(--bg); border: 1px solid var(--line); border-radius: 10px; padding: 6px 8px; text-align: center }
  .chip b { display: block; font-size: 13px; font-variant-numeric: tabular-nums }
  .chip span { font-size: 10px; color: var(--muted) }
  .kw { margin-top: 10px; font-size: 10px; line-height: 1.9 }
  .kw b { font-weight: 600; margin-right: 2px }
  .tag { display: inline-block; padding: 1px 7px; margin: 1px 3px 1px 0; border-radius: 6px; background: var(--bg); color: var(--fg) }
  .tag.have { box-shadow: inset 0 0 0 1px oklch(0.765 0.177 163.223 / 45%) }
  .tag.miss { box-shadow: inset 0 0 0 1px oklch(0.828 0.189 84.429 / 55%) }
  .btn { all: unset; box-sizing: border-box; cursor: pointer; display: block; width: 100%; text-align: center; padding: 10px 12px; border-radius: 12px; font-weight: 600; font-size: 13px; background: var(--chip); color: var(--fg); border: 1px solid var(--line) }
  .btn:hover { border-color: var(--accent) }
  .btn.primary { color: #fff; border: 0; background: linear-gradient(135deg, var(--brand), var(--brand-2)); box-shadow: 0 0 18px oklch(0.585 0.233 277.117 / 35%) }
  .btn[disabled], .btn[aria-disabled="true"] { opacity: .55; cursor: default; box-shadow: none }
  .row { display: flex; gap: 8px; margin-top: 8px }
  .row .btn { flex: 1 }
  h3 { margin: 0 0 8px; font-size: 12px; font-weight: 700; letter-spacing: .02em }
  .list { list-style: none; margin: 8px 0 0; padding: 0; max-height: 220px; overflow: auto }
  .list li { display: flex; gap: 8px; align-items: flex-start; padding: 5px 0; font-size: 12px; border-top: 1px solid var(--line); cursor: pointer }
  .list li:first-child { border-top: 0 }
  .tick { width: 16px; height: 16px; border-radius: 99px; flex: none; margin-top: 1px; display: grid; place-items: center; font-size: 10px; border: 1.5px solid var(--muted); color: transparent }
  .done .tick { background: var(--high); border-color: var(--high); color: #04130c }
  .pct { font-weight: 700; font-variant-numeric: tabular-nums }
  .report ul { margin: 4px 0 0; padding-left: 16px; color: var(--muted) }
  .report li { margin: 2px 0 }
  .report .ok { color: var(--fg) }
  .note { font-size: 11px; color: var(--muted); margin-top: 6px }
  .qa { margin-top: 10px; padding-top: 8px; border-top: 1px solid var(--line) }
  .qa:first-of-type { border-top: 0; padding-top: 0 }
  .qa .qt { font-size: 12px; font-weight: 600; margin-bottom: 6px }
  .qa input { width: 100%; padding: 8px 10px; border-radius: 10px; border: 1px solid var(--line); background: var(--bg); color: var(--fg); font: inherit }
  .opts { display: flex; flex-wrap: wrap; gap: 6px }
  .opt { all: unset; box-sizing: border-box; cursor: pointer; padding: 6px 12px; border-radius: 999px; border: 1px solid var(--line); background: var(--bg); font-size: 12px }
  .opt:hover { border-color: var(--accent) }
  summary { cursor: pointer; font-weight: 700; font-size: 12px }
  details.info summary { color: var(--fg) }
  a { color: var(--accent); text-decoration: none }
  .tab { all: unset; cursor: pointer; position: fixed; right: 0; top: 40%; z-index: 1; padding: 12px 8px; border-radius: 12px 0 0 12px; writing-mode: vertical-rl;
    font: 700 12px -apple-system, sans-serif; color: #fff; background: linear-gradient(135deg, oklch(0.585 0.233 277.117), oklch(0.558 0.288 302.321)); box-shadow: -4px 0 18px oklch(0 0 0 / 35%) }
  .tab[hidden] { display: none }
  .tab.left { right: auto; left: 0; border-radius: 0 12px 12px 0 }
`

function mount() {
  const host = document.createElement('div')
  host.id = 'saaf-overlay-host'
  host.style.cssText = 'all:initial;position:fixed;top:0;right:0;z-index:2147483647'
  document.documentElement.appendChild(host)
  const root = host.attachShadow({ mode: 'open' })
  root.innerHTML = `<style>${STYLE}</style>
    <button class="tab" id="tab" hidden aria-label="Open Jobinko">Jobinko</button>
    <aside class="panel" id="panel" aria-label="Jobinko">
      <header><span class="brand">Jobinko</span><span id="ats"></span><span class="grow"></span><button class="x" id="gear" aria-label="Jobinko settings" title="Settings">⚙</button><button class="x" id="collapse" aria-label="Collapse Jobinko panel" title="Collapse">›</button></header>
      <div class="scroll">
        <section id="account"></section>
        <section id="support"></section>
        <section id="wall"></section>
        <section id="match"><div class="muted">Scoring this posting…</div></section>
        <section id="actions"></section>
        <section id="tailored"></section>
        <section id="dash"></section>
        <section id="ask"></section>
        <section id="report"></section>
      </div>
      <div class="sv" id="sv" hidden></div>
    </aside>`
  const panel = root.getElementById('panel')
  const tab = root.getElementById('tab')
  /**
   * The panel makes room instead of covering the form: the page gets a margin the width of the panel while it is open and
   * gives it back when collapsed. (Narrow windows keep the panel on top: a squeezed form is worse than a covered one.)
   *
   * ⚠️ TWO JOB EXTENSIONS ON ONE PAGE FIGHT FOR THE RIGHT EDGE. The founder runs Jobright and Jobinko side by side, and a
   * second panel on the same edge covers the first. Where another job extension's panel is present, ours docks on the
   * LEFT instead. Checked at mount and again as the other panel finishes loading.
   */
  const PANEL_W = 380
  const OTHER_PANELS = 'plasmo-csui#jobright-helper-plugin, #jobright-helper-plugin, #simplify-jobs-extension, [id^="simplify"][id*="container" i]'
  let side = 'right'
  let open = true
  const apply = () => {
    const wide = window.innerWidth >= 900
    const de = document.documentElement
    de.style.transition = 'margin .2s'
    de.style.marginRight = open && wide && side === 'right' ? `${PANEL_W}px` : ''
    de.style.marginLeft = open && wide && side === 'left' ? `${PANEL_W}px` : ''
    panel.classList.toggle('left', side === 'left')
    tab.classList.toggle('left', side === 'left')
    host.style.cssText = `all:initial;position:fixed;top:0;${side}:0;z-index:2147483647`
  }
  const dock = () => { const next = document.querySelector(OTHER_PANELS) ? 'left' : 'right'; if (next !== side) { side = next; apply() } }
  const setOpen = (o) => { open = o; panel.hidden = !o; tab.hidden = o; apply() }
  apply()
  setTimeout(dock, 1500); setTimeout(dock, 4000); setTimeout(dock, 9000)
  root.getElementById('collapse').addEventListener('click', () => setOpen(false))
  tab.addEventListener('click', () => setOpen(true))
  // Settings, in the panel (as Jobright's gear does): two choices and Save. "More settings" reaches the full settings page.
  const sv = root.getElementById('sv')
  const openSettings = async () => {
    const { jxSettings = {} } = await chrome.storage.local.get('jxSettings')
    const cur = { pageTurn: jxSettings.pageTurn === 'manual' ? 'manual' : 'auto', view: jxSettings.view === 'minimized' ? 'minimized' : 'expanded' }
    const radio = (name, val, label) => `<label class="svr"><input type="radio" name="${name}" value="${val}" ${cur[name] === val ? 'checked' : ''}> ${label}</label>`
    sv.innerHTML = `<div class="svh"><button class="x" id="svx" aria-label="Close settings">✕</button><b>Settings</b></div>
      <div class="svb">
        <h4>Autofill After Page Turn</h4>${radio('pageTurn', 'auto', 'Automatically')}${radio('pageTurn', 'manual', 'Manually')}
        <div class="muted">Automatically: when an application moves to its next step, Jobinko fills that step too. It never presses Submit.</div>
        <h4>Default Plugin View</h4>${radio('view', 'expanded', 'Expanded')}${radio('view', 'minimized', 'Minimized')}
        <div class="muted" style="margin-top:14px"><a href="#" id="svmore">More settings</a> — phone, notice period, pay, Apply for me.</div>
      </div>
      <div class="svf"><button class="btn primary" id="svsave" style="width:100%">Save</button><div class="note" id="svnote"></div></div>`
    sv.hidden = false
    sv.querySelector('#svx').addEventListener('click', () => { sv.hidden = true })
    sv.querySelector('#svmore').addEventListener('click', (e) => { e.preventDefault(); chrome.runtime.sendMessage({ type: 'jx:open-options' }) })
    sv.querySelector('#svsave').addEventListener('click', async () => {
      const pick = (n) => sv.querySelector(`input[name="${n}"]:checked`)?.value
      await chrome.storage.local.set({ jxSettings: { pageTurn: pick('pageTurn') === 'manual' ? 'manual' : 'auto', view: pick('view') === 'minimized' ? 'minimized' : 'expanded' } })
      sv.querySelector('#svnote').textContent = 'Saved.'
      setTimeout(() => { sv.hidden = true }, 500)
    })
  }
  root.getElementById('gear').addEventListener('click', () => { if (sv.hidden) openSettings(); else sv.hidden = true })
  // Default Plugin View: "Minimized" starts collapsed to the edge tab (unless the toolbar icon just asked for the panel).
  chrome.storage.local.get('jxSettings').then(({ jxSettings }) => { if (jxSettings?.view === 'minimized' && !globalThis.__jxForce) setOpen(false) })
  // The toolbar icon: opens the panel if it is collapsed, collapses it if it is open (service-worker.js, "The toolbar icon").
  // The page may rebuild the panel as it changes (below), so the listener is registered ONCE and calls whichever panel is current.
  globalThis.__jxPanelToggle = () => setOpen(panel.hidden)
  if (!globalThis.__jxMsgBound) {
    globalThis.__jxMsgBound = true
    chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
      if (msg?.type === 'jx:ping') { sendResponse({ ok: !!globalThis.__jxMounted }); return false }
      if (msg?.type !== 'jx:toggle' || !globalThis.__jxPanelToggle) return false
      globalThis.__jxPanelToggle()
      sendResponse({ ok: true })
      return false
    })
  }
  return root
}

function ring(score) {
  const color = score >= 75 ? 'var(--high)' : score >= 60 ? 'var(--mid)' : 'var(--low)'
  const r = 25, c = 2 * Math.PI * r, dash = (Math.max(0, Math.min(100, score)) / 100) * c
  return `<div class="ring"><svg width="58" height="58" viewBox="0 0 58 58">
    <circle cx="29" cy="29" r="${r}" fill="none" stroke="var(--bg)" stroke-width="5"/>
    <circle cx="29" cy="29" r="${r}" fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round"
      stroke-dasharray="${dash} ${c}"/></svg><b>${esc(score)}</b></div>`
}

/** Who is connected: the signed-in account and the résumé that will be attached, or a way to sign in. */
function renderAccount(root, state) {
  const el = root.getElementById('account')
  if (state.signedIn === true) {
    const resume = state.resumeFile
      ? `${state.resumeFile.tailored ? 'Attaching your <b>tailored</b> résumé' : 'Attaching'} <b>${esc(state.resumeFile.name)}</b>`
      : 'No résumé on Jobinko yet — <a href="' + SITE + '/resume" target="_blank" rel="noopener">add one</a>'
    el.innerHTML = `<div class="box"><div><b>${esc(state.account?.name || state.account?.email || 'Signed in')}</b> <span class="muted">· connected</span></div><div class="muted" style="margin-top:2px">${resume}</div></div>`
  } else if (state.signedIn === false) {
    el.innerHTML = `<div class="box"><div><b>Sign in to Jobinko</b></div>
      <div class="muted" style="margin:2px 0 8px">To autofill, save jobs and attach your résumé, the extension uses your Jobinko account.</div>
      <a class="btn primary" id="signin" href="${SITE}/signin" target="_blank" rel="noopener">Sign in to Jobinko</a>
      <button class="btn" id="recheck" style="margin-top:8px">I’ve signed in — reconnect</button></div>`
    root.getElementById('recheck').addEventListener('click', () => state.reconnect())
  } else {
    el.innerHTML = `<div class="box muted">${esc(state.error || 'Connecting to your Jobinko account…')}</div>`
  }
}

function renderMatch(root, job, data) {
  const el = root.getElementById('match')
  if (job.atsPlatform) root.getElementById('ats').innerHTML = `<span class="badge">${esc(job.atsPlatform)}</span>`
  if (!data?.ok) {
    el.innerHTML = `<div class="box">${esc(data?.error ?? 'Could not score this posting.')}</div>`
    return
  }
  // ⚠️ NO COMPONENT COUNT IN THIS COPY. This path omits work mode, so it is five components and not seven, and a stated
  // number goes stale the next time the scorer changes shape.
  const chips = (data.components ?? []).slice(0, 6).map((c) => {
    const pct = c.max ? Math.round((c.points / c.max) * 100) : 0
    const color = pct >= 75 ? 'var(--high)' : pct >= 50 ? 'var(--mid)' : 'var(--low)'
    return `<div class="chip"><b style="color:${color}">${esc(c.points)}/${esc(c.max)}</b><span>${esc(c.label)}</span></div>`
  }).join('')
  /**
   * Missing keywords. Ours come from a vocabulary mined out of our own index, so a term is listed only because at least
   * twelve distinct employers name it. That is what stops it saying your résumé is missing "synergy".
   */
  const tags = (list, cls) => list.slice(0, 8).map((t) => `<span class="tag ${cls}">${esc(t)}</span>`).join('')
  const kw = []
  if (data.matched?.length) kw.push(`<div><b>You have</b> ${tags(data.matched, 'have')}</div>`)
  if (data.missing?.length) kw.push(`<div><b>Not on your résumé</b> ${tags(data.missing, 'miss')}</div>`)
  el.innerHTML = `<div class="box">
    <div class="head">${ring(data.total)}
      <div class="job"><div class="t">${esc(job.title || 'This posting')}</div>
        <div class="muted">${esc([job.company, job.location].filter(Boolean).join(' · ') || 'match out of 100')}</div></div></div>
    <div class="chips">${chips}</div>
    ${kw.length ? `<div class="kw">${kw.join('')}</div>` : ''}</div>`
}

const save = (job, status) => chrome.runtime.sendMessage({
  type: 'jx:save',
  item: { url: job.pageUrl, title: job.title || 'Untitled role', company: job.company || new URL(job.pageUrl).hostname, ats: job.atsPlatform, status },
})

/**
 * The panel's working half, laid out like the reference's: Autofill, then what it fills with ("Your autofill information"),
 * the résumé it will attach (with Tailor beside it), Save job, and — as it runs — live progress with the page's own
 * Required and Optional fields, each ticked as it is filled, collapsing to "6/6 required fields filled" when done.
 */
function mountActions(root, job, state) {
  const doc = document
  const A = globalThis.SaafAutofill
  const A2 = globalThis.SaafAutoApply
  const actions = root.getElementById('actions')
  const dash = root.getElementById('dash')
  const report = root.getElementById('report')
  const pk = pageKey(job.pageUrl)
  /**
   * ⚠️ THE FORM OFTEN ARRIVES AFTER THE PANEL. Greenhouse renders the application below the description, Lever puts it
   * on a separate /apply URL, and several ATS front ends mount it client-side a beat later. So the Autofill button
   * enables when a form does, and the observer stops after 15 s — one left running for the life of the tab is a cost
   * every page pays forever.
   */
  const FORM_SELECTOR = 'input[type="email"], input[type="tel"], input[type="file"], form input[type="text"], form input:not([type]), form select'
  const hasForm = () => !!doc.querySelector(FORM_SELECTOR)

  actions.innerHTML = `
    <button class="btn primary" id="go" disabled>⚡ Autofill</button>
    <div class="note" id="gonote"></div>
    <button class="btn" id="apply" style="margin-top:8px" disabled>Apply on this page</button>
    <div id="applybox"></div>
    <div id="submitbox"></div>
    <button class="box info" id="info" style="margin-top:10px;width:100%;display:flex;justify-content:space-between;align-items:center;font:inherit;color:inherit;cursor:pointer;text-align:left"><span>Your autofill information</span><span aria-hidden="true">›</span></button>
    <div class="box" id="resumerow" style="margin-top:8px">
      <div id="rrow" role="button" tabindex="0" title="Choose which résumé to attach" style="display:flex;justify-content:space-between;gap:8px;align-items:baseline;cursor:pointer"><b>Résumé</b><span class="muted" id="rname" style="flex:1;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span><span aria-hidden="true">›</span></div>
      <button class="btn" id="tailor" style="margin-top:8px">✦ Tailor résumé for this job</button>
    </div>
    <div class="box" id="coverrow" style="margin-top:8px">
      <div id="crow" role="button" tabindex="0" title="Write or edit a cover letter for this job" style="display:flex;justify-content:space-between;gap:8px;align-items:baseline;cursor:pointer"><b>Cover letter</b><span class="muted" id="cname" style="flex:1;text-align:right"></span><span aria-hidden="true">›</span></div>
      <button class="btn" id="cover" style="margin-top:8px">✦ Generate cover letter</button>
    </div>
    <button class="btn" id="save" style="margin-top:8px">Save job</button>
    <div class="note" id="savenote"></div>`
  const go = root.getElementById('go')
  const gonote = root.getElementById('gonote')
  const supportEl = root.getElementById('support')
  const saveBtn = root.getElementById('save')
  const saveNote = root.getElementById('savenote')
  const tailorBtn = root.getElementById('tailor')
  const tailored = root.getElementById('tailored')

  const applyBtn = root.getElementById('apply')
  // Everything this panel registers outside its own DOM is undone when the page changes and the panel is rebuilt.
  state.cleanups = []
  const onStore = (fn) => { chrome.storage.onChanged.addListener(fn); state.cleanups.push(() => chrome.storage.onChanged.removeListener(fn)) }
  // The one button. With a sign-up password saved it ALSO does the account step — but only on a page that needs an account
  // (an account form is showing, or the site is one that makes you sign up first). On any other page it is plain Autofill.
  const ACCOUNT_SITES = ['Workday', 'iCIMS', 'Taleo', 'SuccessFactors']
  const needsAccount = () => !!globalThis.SaafAccount?.kind(doc) || ACCOUNT_SITES.includes(job.atsPlatform || '')
  const goLabel = () => (state.filledOnce ? 'Autofill again' : state.hasPw && needsAccount() ? '⚡ Account creation & Autofill' : '⚡ Autofill')
  state.hasPw = false
  const setSupport = () => {
    const form = hasForm()
    const entry = !form && !!globalThis.SaafAutoApply.findApplyEntry(doc)
    // Autofill works with a form on the page, or — new — with an Apply button it can press itself.
    go.disabled = state.running || !(form || entry)
    applyBtn.disabled = state.running || !(form || entry)
    renderWall(root, state)
    const msg = form ? `Autofill supported${job.atsPlatform ? ' · ' + esc(job.atsPlatform) : ''}`
      : entry ? 'Jobinko will press Apply for you, then fill the form'
      : 'No application form or Apply button found on this page'
    supportEl.innerHTML = `<div class="support ${form || entry ? '' : 'off'}"><span class="dot"></span>${msg}</div>`
    if (!state.running && go.textContent !== 'Autofilling…') go.textContent = goLabel()
  }
  setSupport()

  // The one button, as Jobright names it: with a sign-up password saved it also does the account step.
  // What this step of the application looks like: its fields, and whether it is an account form. A change means a new step.
  const formSig = () => A.checklist(doc).items.map((i) => i.label).join('|') + '#' + (globalThis.SaafAccount?.kind(doc) || '')
  const refreshPw = async () => { const { accountPassword } = await chrome.storage.local.get('accountPassword'); state.hasPw = !!accountPassword; if (!state.running) go.textContent = goLabel() }
  onStore((c, area) => { if (area === 'local' && c.accountPassword) refreshPw() })
  refreshPw()

  // Résumé row: which file will be attached.
  state.drawResume = () => { root.getElementById('rname').textContent = state.resumeFile ? `${state.resumeFile.tailored ? 'Tailored · ' : ''}${state.resumeFile.name}` : 'none yet' }
  state.drawResume()

  // "Your autofill information": the pop-up (below) — what the filler will type, and the sign-up password.
  state.openInfo = (tab) => openAutofillModal(root, state, tab)
  root.getElementById('rrow').addEventListener('click', () => openResumePicker(root, state))
  // Cover letter: written from this posting on request, read and edited by the person, and used by Autofill only after they
  // press "Use this letter" — attached to a cover-letter upload box, or typed into a cover-letter text box.
  const cname = root.getElementById('cname'); const coverBtn = root.getElementById('cover')
  state.drawCover = async () => {
    const { coverFor = {} } = await chrome.storage.local.get('coverFor')
    const c = coverFor[pk]
    cname.textContent = c ? 'Ready ✓' : 'none yet'
    coverBtn.textContent = c ? '✎ Edit cover letter' : '✦ Generate cover letter'
  }
  state.drawCover()
  // "Anything else we should know?" — the person's own notes, offered (never filled by itself) beside free-text questions.
  const loadNotes = async () => { state.notes = ((await chrome.storage.local.get('profile')).profile || {}).anythingElse || '' }
  loadNotes()
  onStore((ch, area) => { if (area === 'local' && ch.profile) loadNotes() })
  onStore((ch, area) => { if (area === 'local' && ch.coverFor) state.drawCover() })
  const openCover = () => openCoverLetter(root, state, job, pk)
  coverBtn.addEventListener('click', openCover)
  root.getElementById('crow').addEventListener('click', openCover)
  root.getElementById('info').addEventListener('click', () => state.openInfo('personal'))

  // Save job — straight onto the tracker; falls back to a queue when signed out.
  async function showSaved() {
    const { tracked = [], pendingTrack = [] } = await chrome.storage.local.get(['tracked', 'pendingTrack'])
    const on = tracked.find((t) => pageKey(t.url) === pk)
    const queued = pendingTrack.find((t) => pageKey(t.url) === pk)
    if (on) { saveBtn.textContent = `✓ ${STAGE_LABEL[on.status] ?? on.status}`; saveNote.innerHTML = `On your Jobinko tracker · <a href="${SITE}/applications" target="_blank" rel="noopener">open it</a>` }
    else if (queued) { saveBtn.textContent = '✓ Saved'; saveNote.innerHTML = `Not signed in — it goes on your tracker next time Jobinko is open. <a href="${SITE}/applications" target="_blank" rel="noopener">Open Jobinko</a>` }
    else { saveBtn.textContent = 'Save job'; saveNote.textContent = '' }
  }
  saveBtn.addEventListener('click', async () => {
    saveBtn.disabled = true
    saveBtn.textContent = 'Saving…'
    const r = await save(job, 'saved').catch(() => null)
    saveBtn.disabled = false
    if (!r?.ok) { saveBtn.textContent = 'Save job'; saveNote.textContent = r?.error || 'Could not save it just now.'; return }
    await showSaved()
  })
  showSaved()
  onStore((changes, area) => { if (area === 'local' && (changes.tracked || changes.pendingTrack)) showSaved() })

  // Tailor — rewrites your résumé for THIS posting on Jobinko (same engine and honesty guard as the website), keeps it as a
  // saved résumé, and attaches exactly that file on this application.
  function drawTailored(t) {
    if (!t) { tailored.innerHTML = ''; return }
    const sc = t.scores?.before != null && t.scores?.after != null ? `Match ${esc(t.scores.before)} → <b>${esc(t.scores.after)}</b> · ` : ''
    tailored.innerHTML = `<div class="box"><h3>Tailored résumé</h3>
      <div>${sc}${esc(t.changed ?? 0)} line${t.changed === 1 ? '' : 's'} reworded for this role</div>
      <div class="muted" style="margin-top:2px">Every line is checked against your own original; anything it could not support was left as you wrote it.</div>
      <div class="row"><a class="btn" href="${SITE}/resume/edit/${esc(t.id)}" target="_blank" rel="noopener">View &amp; edit</a><button class="btn" id="untailor">Use my main résumé</button></div>
      <div class="note">${hasForm() ? 'Press <b>Autofill again</b> to attach it to this application.' : 'It will be attached when you press Autofill.'}</div></div>`
    root.getElementById('untailor').addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'jx:untailor', pageKey: pk })
      await state.reconnect()
      drawTailored(null)
    })
  }
  state.drawTailored = drawTailored
  tailorBtn.addEventListener('click', async () => {
    tailorBtn.disabled = true
    tailorBtn.textContent = 'Tailoring… about 20 seconds'
    const r = await chrome.runtime.sendMessage({ type: 'jx:tailor', pageKey: pk, jdText: job.description, jdTitle: job.title, company: job.company }).catch(() => null)
    tailorBtn.disabled = false
    tailorBtn.textContent = '✦ Tailor résumé for this job'
    if (r?.signedIn === false) { state.signedIn = false; renderAccount(root, state); return }
    if (!r?.ok) { tailored.innerHTML = `<div class="box">${esc(r?.error || 'Could not tailor it just now.')}</div>`; return }
    state.resumeFile = r.file ? { name: r.file.name, tailored: true } : state.resumeFile
    renderAccount(root, state)
    state.drawResume()
    drawTailored(r)
  })

  // The Required and Optional lists, drawn from the page's own marks, ticked live while Autofill runs.
  const row = (i, n) => `<li class="${i.done ? 'done' : ''}" data-n="${n}"><span class="tick">✓</span><span>${esc(i.label)}</span></li>`
  let shown = []
  function drawDashboard() {
    const c = A.checklist(doc)
    shown = c.items
    if (!c.items.length) { dash.innerHTML = ''; return c }
    const counted = c.counted
    const pct = c.required ? Math.round((c.done / c.required) * 100) : 0
    const hasReq = c.items.some((i) => i.required)
    const head = state.running
      ? `<div style="display:flex;justify-content:space-between;align-items:baseline"><b>Autofilling…</b><span class="pct">${pct}%</span><button class="x" id="cancel" style="font-size:12px;text-decoration:underline">Cancel</button></div>`
      : `<div style="display:flex;justify-content:space-between;align-items:baseline"><b>${c.done}/${c.required} ${hasReq ? 'required ' : ''}fields filled</b><span class="pct">${pct}%</span></div>`
    const req = c.items.map((i, n) => [i, n]).filter(([i]) => i.required)
    const opt = c.items.map((i, n) => [i, n]).filter(([i]) => !i.required)
    const list = (title, rows) => rows.length ? `<div class="muted" style="margin-top:10px;font-weight:700">${title}</div><ul class="list">${rows.map(([i, n]) => row(i, n)).join('')}</ul>` : ''
    dash.innerHTML = `<div class="box"><h3>Application dashboard</h3>${head}<div class="bar" style="margin-top:6px"><i style="width:${pct}%"></i></div>
      <details ${state.running || !state.collapsed ? 'open' : ''} id="dlist"><summary class="muted" style="cursor:pointer;margin-top:8px">${state.running ? 'Fields' : 'Show fields'}</summary>${list('Required', req)}${list(hasReq ? 'Optional' : 'Fields', opt.length || !hasReq ? opt : [])}</details></div>`
    void counted
    dash.querySelectorAll('li').forEach((li) => li.addEventListener('click', () => {
      const el = shown[Number(li.dataset.n)]?.el
      if (!el) return
      el.scrollIntoView({ block: 'center', behavior: 'smooth' })
      try { el.focus({ preventScroll: true }) } catch { /* not focusable */ }
    }))
    root.getElementById('cancel')?.addEventListener('click', () => { state.cancel = true })
    root.getElementById('dlist')?.addEventListener('toggle', (e) => { state.collapsed = !e.currentTarget.open })
    return c
  }
  const refreshDashboard = () => { if (hasForm() && !state.running) drawDashboard(); else if (!hasForm()) dash.innerHTML = '' }
  refreshDashboard()
  // The person types answers themselves too; keep the bar honest (cheap: only while a form exists).
  const redraw = () => { clearTimeout(refreshDashboard.t); refreshDashboard.t = setTimeout(refreshDashboard, 300) }
  doc.addEventListener('input', redraw, true)
  doc.addEventListener('change', redraw, true)
  state.cleanups.push(() => { doc.removeEventListener('input', redraw, true); doc.removeEventListener('change', redraw, true); clearTimeout(refreshDashboard.t) })

  const submitbox = root.getElementById('submitbox')

  /**
   * "Questions for you": the required questions the form asked that Jobinko has no saved answer for. Answered here — typed or
   * chosen — the answer is written into the form, kept in the person's Jobinko answer bank, and used on the next form that asks
   * the same thing. Demographic and credential questions are never listed (they stay the person's, on the form).
   */
  const askEl = root.getElementById('ask')
  function drawQuestions() {
    const qs = A.questions(doc)
    if (!qs.length) { askEl.innerHTML = ''; return qs }
    askEl.innerHTML = `<div class="box"><h3>Questions for you</h3>
      <div class="muted">This form asks ${qs.length === 1 ? 'this' : 'these'} and Jobinko has no saved answer. Answer once — it is filled in here and remembered for the next form.</div>
      ${qs.map((q, i) => `<div class="qa" data-i="${i}"><div class="qt">${esc(q.question)}</div>
        ${q.kind === 'text' ? `<div style="display:flex;gap:6px"><input data-q="${i}" placeholder="Your answer"><button class="opt" data-save="${i}">Save</button></div>${state.notes ? `<a href="#" data-notes="${i}" class="muted" style="display:inline-block;margin-top:4px">Insert my notes</a>` : ''}`
          : `<div class="opts">${q.options.map((o, n) => `<button class="opt" data-pick="${i}" data-n="${n}">${esc(o)}</button>`).join('')}</div>`}</div>`).join('')}
      <div class="note" id="asknote"></div></div>`
    const submitAnswer = async (q, value) => {
      const note = root.getElementById('asknote')
      if (!A.answerQuestion(q, value)) { note.textContent = 'The page would not take that — please answer it on the form.'; return }
      chrome.runtime.sendMessage({ type: 'jx:answer', key: q.key, question: q.question, answer: value }).then((r) => {
        const n = root.getElementById('asknote'); if (n) n.textContent = (r?.saved ? 'Saved to your Jobinko answers — used next time.' : 'Filled in. (Could not reach Jobinko to keep it — kept in this browser.)')
      }).catch(() => {})
      state.answered = true
      setTimeout(() => { drawDashboard(); drawQuestions(); if (state.filledOnce) offerSubmit() }, 120)
    }
    askEl.querySelectorAll('[data-save]').forEach((b) => b.addEventListener('click', () => {
      const i = Number(b.dataset.save); const v = askEl.querySelector(`input[data-q="${i}"]`).value
      if (v.trim()) submitAnswer(qs[i], v)
    }))
    askEl.querySelectorAll('input[data-q]').forEach((inp) => inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') askEl.querySelector(`[data-save="${inp.dataset.q}"]`).click() }))
    askEl.querySelectorAll('[data-notes]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); const inp = askEl.querySelector(`input[data-q="${a.dataset.notes}"]`); inp.value = state.notes.slice(0, 1000); inp.focus() }))
    askEl.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => { const q = qs[Number(b.dataset.pick)]; submitAnswer(q, q.options[Number(b.dataset.n)]) }))
    return qs
  }

  /** Fill the form on THIS page, with live progress, then offer the Submit step. */
  async function fillNow() {
    state.running = true; state.cancel = false; state.collapsed = false
    go.disabled = true
    go.textContent = 'Autofilling…'
    report.innerHTML = ''
    submitbox.innerHTML = ''
    // Bring the profile, answers and résumé file up to date from the account, then fill.
    const conn = await chrome.runtime.sendMessage({ type: 'jx:connect', pageKey: pk }).catch(() => null)
    if (conn) { state.signedIn = conn.signedIn; state.account = conn.account; state.resumeFile = conn.resumeFile; renderAccount(root, state); state.drawResume() }
    const { profile, resumeFile, coverFor = {} } = await chrome.storage.local.get(['profile', 'resumeFile', 'coverFor'])
    if (!profile || !profile.fullName) {
      state.running = false
      report.innerHTML = '<div class="box report">We have no details to fill with yet. Sign in to Jobinko and finish your profile — or open Jobinko once while signed in and they sync.</div>'
      go.textContent = goLabel(); setSupport()
      return
    }
    // Live progress: redraw the lists from the page's own state while the filler works.
    drawDashboard()
    const tick = setInterval(drawDashboard, 150)
    let res
    try {
      res = await A.fillForm(profile, doc, { resumeFile, coverLetter: coverFor[pk] || null, replaceResumeNamed: state.attachedName, shouldStop: () => state.cancel })
    } finally {
      clearInterval(tick)
      state.running = false
    }
    const att = res.filled.find((f) => f.how === 'attached')
    if (att) state.attachedName = att.value
    if (res.unanswered.length) chrome.runtime.sendMessage({ type: 'saaf:questions', items: res.unanswered })
    const how = { typed: 'Typed', chose: 'Chose', ticked: 'Ticked', attached: 'Attached' }
    const picks = res.filled.map((f) => `<li class="ok">${how[f.how] ?? 'Filled'}: ${esc(f.value)}</li>`).join('')
    const left = res.refused.map((r) => `<li>${esc(r.reason)}</li>`).join('')
    report.innerHTML = `<div class="box report">
      <b>${state.cancel ? 'Stopped. ' : ''}Filled ${res.filled.length} field${res.filled.length === 1 ? '' : 's'}.</b> Check them before you submit.
      ${picks ? `<ul>${picks}</ul>` : ''}
      ${left ? `<div class="muted" style="margin-top:6px">Left for you:</div><ul>${left}</ul>` : ''}
      ${res.unanswered.length ? `<div class="muted" style="margin-top:6px">${res.unanswered.length} question${res.unanswered.length === 1 ? '' : 's'} on this form ${res.unanswered.length === 1 ? 'needs' : 'need'} your own answer. Write ${res.unanswered.length === 1 ? 'it' : 'each'} once in Jobinko → Profile → Templates, and it is filled next time it is asked.</div>` : ''}</div>`
    go.textContent = 'Autofill again'
    setSupport()
    state.collapsed = !state.cancel // like the reference: finish → collapse to the summary line
    drawDashboard()
    // Filling a form is the candidate applying, so the role goes on the tracker as Applying. It never reaches Applied
    // from here: we cannot see whether they pressed Submit, and saying they did would be a guess.
    if (res.filled.length) { await save(job, 'applying'); showSaved() }
    state.filledOnce = true
    state.sig = formSig()
    chrome.storage.local.set({ appSession: { host: location.host, at: Date.now() } })
    gonote.textContent = ''
    drawQuestions()
    offerSubmit()
  }

  /**
   * After the form is filled: ask. The person reads the form and presses Submit themselves — or presses it here, which
   * runs the same checks as the one-click flow (nothing required empty, no CAPTCHA, the kill switch) and counts the
   * application as sent only when the employer's page confirms it.
   */
  function offerSubmit() {
    // A sign-in or create-account page is not an application to submit; the account helper above handles it.
    if (globalThis.SaafAccount?.kind(doc)) { submitbox.innerHTML = ''; return }
    const submit = A2.findSubmit(doc)
    if (!submit) {
      submitbox.innerHTML = `<div class="box" style="margin-top:8px"><b>Filled.</b> <span class="muted">This step has no Submit button — press the site’s own Next or Continue, then press <b>Autofill again</b> on the next step.</span></div>`
      return
    }
    submitbox.innerHTML = `<div class="box" style="margin-top:8px"><b>Ready to submit?</b>
      <div class="muted" style="margin:4px 0 8px">Read the form first. Jobinko presses Submit only when every required answer is filled, and counts it as sent only when the employer’s page confirms it.</div>
      <div class="row"><button class="btn primary" id="submitnow">Submit application</button><button class="btn" id="submitlater">I’ll review first</button></div></div>`
    root.getElementById('submitlater').addEventListener('click', () => { submitbox.innerHTML = '' })
    root.getElementById('submitnow').addEventListener('click', async () => {
      state.submitting = true // the page may change under us as it confirms — the panel must not be rebuilt mid-submit
      submitbox.innerHTML = '<div class="box muted" style="margin-top:8px">Submitting… keep this tab open.</div>'
      const ok = await chrome.runtime.sendMessage({ type: 'saaf:autoapply-here', job: { url: job.pageUrl, title: job.title, company: job.company } }).catch(() => null)
      if (!ok?.ok) { state.submitting = false; submitbox.innerHTML = `<div class="box" style="margin-top:8px">${esc(ok?.error || 'Could not start.')}</div>`; return }
      const beforeSubmit = () => chrome.runtime.sendMessage({ type: 'saaf:autoapply-phase', phase: 'await-confirm' })
      const r = await A2.submitOnly(doc, { beforeSubmit }, {}).catch(() => ({ status: 'needs-you', reason: 'Something went wrong — check this page' }))
      await chrome.runtime.sendMessage({ type: 'saaf:autoapply-result', status: r.status, reason: r.reason, coverage: r.coverage }).catch(() => {})
      submitbox.innerHTML = ''
      state.submitting = false
      renderApplyResult(root, { here: true, status: r.status, reason: r.reason, coverage: r.coverage })
    })
  }

  /**
   * The Autofill button. On a posting page with no form it PRESSES APPLY ITSELF first — the form may open on this page, on
   * the next page, or in a new tab — and the fill carries on wherever the form appears (the note left in storage, below).
   */
  async function startAutofill() {
    if (state.running) return
    // An account wall comes first: create the account / sign in with the saved password, then carry on at the next page.
    const wallKind = globalThis.SaafAccount?.kind(doc)
    if (wallKind) {
      state.running = true; go.textContent = 'Creating your account…'
      state.sig = formSig()
      chrome.storage.local.set({ appSession: { host: location.host, at: Date.now() } })
      const r = await accountStep(state, wallKind)
      state.running = false; go.textContent = goLabel()
      if (r.needsPassword) { openAutofillModal(root, state, 'signup'); return }
      const n = root.getElementById('wallnote')
      if (n) n.textContent = r.text
      report.innerHTML = `<div class="box report ${r.done ? '' : 'muted'}">${esc(r.text)}</div>`
      return
    }
    if (!hasForm()) {
      const entry = A2.findApplyEntry(doc)
      if (!entry) { report.innerHTML = '<div class="box report">I could not find an Apply button on this page. Open the application form and press Autofill.</div>'; return }
      state.running = true; setSupport()
      go.textContent = 'Opening the application…'
      // A note for whichever page the form turns up on (this one, the next, or a new tab); it expires in 90 seconds.
      await chrome.storage.local.set({ autofillPending: { at: Date.now() } })
      entry.click()
      // A pop-up of ways to start ("Apply Manually"…) may stand between Apply and the form: take the manual one.
      let appeared = false
      for (let step = 0; step < 3 && !appeared; step++) {
        appeared = await A2.waitForForm(doc, 4000)
        if (appeared) break
        const choice = A2.findApplyChoice(doc)
        if (choice) choice.click()
      }
      if (!appeared) appeared = await A2.waitForForm(doc, 4000)
      state.running = false
      if (!appeared) {
        // The page is navigating, or the application opened elsewhere: that page's panel takes over from the note.
        go.textContent = goLabel()
        setSupport()
        report.innerHTML = '<div class="box report muted">Opening the application… the form will be filled as soon as it appears (on this page or in a new tab).</div>'
        return
      }
      await chrome.storage.local.remove('autofillPending')
    }
    await fillNow()
  }
  go.addEventListener('click', () => startAutofill())
  state.autofill = startAutofill
  state.hasForm = hasForm

  // Apply on this page — fills, checks, and presses Submit only when everything required is answered from the person's
  // own details. Their press is the consent for THIS application; the rules (autoapply.js) do not change: no CAPTCHAs,
  // no guessing, "applied" only when the employer's page confirms it.
  const applybox = root.getElementById('applybox')
  applyBtn.addEventListener('click', () => {
    applybox.innerHTML = `<div class="box" style="margin-top:8px"><b>Apply on this page?</b>
      <div class="muted" style="margin:4px 0 8px">Jobinko fills this form from your saved details and presses Submit — but only when every required answer is filled. It stops, and leaves the page to you, at a CAPTCHA, at a question it has no answer for, or at a required file it does not have. It counts the application as sent only when the employer’s page confirms it. Up to 25 a day.</div>
      <div class="row"><button class="btn primary" id="applyyes">Fill &amp; submit</button><button class="btn" id="applyno">Cancel</button></div></div>`
    root.getElementById('applyno').addEventListener('click', () => { applybox.innerHTML = '' })
    root.getElementById('applyyes').addEventListener('click', async () => {
      applybox.innerHTML = '<div class="box muted" style="margin-top:8px">Applying… keep this tab open.</div>'
      state.running = true; setSupport(); go.disabled = true
      // Fresh profile and résumé from the account first, then register this tab as the one application running.
      await chrome.runtime.sendMessage({ type: 'jx:connect', pageKey: pk }).catch(() => null)
      const ok = await chrome.runtime.sendMessage({ type: 'saaf:autoapply-here', job: { url: job.pageUrl, title: job.title, company: job.company } }).catch(() => null)
      if (!ok?.ok) {
        state.running = false; setSupport(); go.disabled = !hasForm()
        applybox.innerHTML = `<div class="box" style="margin-top:8px">${esc(ok?.error || 'Could not start.')}</div>`
        return
      }
      const out = await autoApplyIfAssigned()
      state.running = false; setSupport(); go.disabled = !hasForm()
      renderApplyResult(root, out)
      applybox.innerHTML = ''
      refreshDashboard()
    })
  })

  // Single-page job systems (Workday, Ashby…) draw the Apply button and the form AFTER the page loads and again at every
  // step, so the panel keeps looking: on each burst of changes (debounced) it re-reads whether there is a form or an Apply
  // button. Five minutes, then it stops — a watcher left running for the life of the tab is a cost every page pays.
  // Re-read the page: is there a form, an account form, a new step? Called when the page's content changes AND on a one-second beat
  // (below) — never only on a change: a change that arrives while the panel is busy (pressing Apply, filling) would otherwise be
  // ignored and, with nothing after it to trigger another look, never noticed at all.
  let reading = false
  const reassess = async () => {
    if (state.running || reading || document.visibilityState === 'hidden') return
    reading = true
    try {
      setSupport(); refreshDashboard()
      // A later step of the same application (Workday's My Information → My Experience → …). "Autofill After Page Turn" decides:
      // Automatically (the default, as in Jobright) fills the new step; Manually only says so. Never presses Submit.
      const wallNow = globalThis.SaafAccount?.kind(doc)
      if (!hasForm() && !wallNow) return
      const sig = formSig()
      if (!sig || sig === state.sig) return
      const { jxSettings = {}, appSession, autofillPending } = await chrome.storage.local.get(['jxSettings', 'appSession', 'autofillPending'])
      const recent = (t, ms) => !!t && Date.now() - t.at < ms
      const inProgress = state.filledOnce || (appSession?.host === location.host && recent(appSession, 30 * 60_000)) || recent(autofillPending, 90_000)
      if (!inProgress) { state.sig = sig; return }
      if (jxSettings.pageTurn !== 'manual' && (state.autoRuns = (state.autoRuns || 0) + 1) <= 25) { state.sig = sig; state.autofill?.(); return }
      if (state.filledOnce) { gonote.textContent = 'This looks like a new step — press Autofill again to fill it.'; submitbox.innerHTML = ''; askEl.innerHTML = '' }
    } finally { reading = false }
  }
  state.reassess = reassess
  let watch
  const obs = new MutationObserver(() => { clearTimeout(watch); watch = setTimeout(reassess, 400) })
  obs.observe(doc.body, { childList: true, subtree: true })
  // No time limit: a single-page site changes under the panel at any moment, and a panel that stopped looking after five minutes
  // kept showing the old page's account box on the next application. The callback is cheap and idle while the tab is hidden.
  state.cleanups.push(() => { obs.disconnect(); clearTimeout(watch) })
  state.stop = () => { state.cleanups.splice(0).forEach((f) => { try { f() } catch { /* already gone */ } }) }
}

/**
 * "Apply for me" on this tab, when the service worker assigned it one
 * (autoapply.js holds the rules). Phases: 'fill' → (click Submit) →
 * 'await-confirm' on whatever page loads next.
 */
async function autoApplyIfAssigned() {
  const state = await chrome.runtime.sendMessage({ type: 'saaf:autoapply-state' }).catch(() => null)
  if (!state) return null
  const here = !!state.here
  const report = async (status, reason, coverage) => {
    await chrome.runtime.sendMessage({ type: 'saaf:autoapply-result', status, reason, coverage })
    return { here, status, reason, coverage }
  }
  const A = globalThis.SaafAutoApply

  if (state.phase === 'await-confirm') {
    for (let i = 0; i < 20; i++) {
      if (A.confirmationSeen(document)) return report('submitted', 'The employer’s page confirmed it')
      await new Promise((r) => setTimeout(r, 500))
    }
    return report('unconfirmed', 'Submitted, but the next page showed no confirmation — check this tab')
  }

  const { profile, resumeFile } = await chrome.storage.local.get(['profile', 'resumeFile'])
  if (!profile?.fullName) return report('needs-you', 'Add your details in the Jobinko extension first')
  const beforeSubmit = () => chrome.runtime.sendMessage({ type: 'saaf:autoapply-phase', phase: 'await-confirm' })
  // A person who pressed Apply may use any answer they saved; a queued background run uses only those they marked for it.
  const mode = here ? 'manual' : 'auto'
  let r = await A.run(document, profile, { resumeFile, beforeSubmit, mode })
  if (r.status === 'open-form') {
    // Same-page forms appear a beat after the Apply button; a navigating one reloads this script.
    await new Promise((res) => setTimeout(res, 3000))
    r = await A.run(document, profile, { resumeFile, beforeSubmit, mode })
    if (r.status === 'open-form') r = { status: 'needs-you', reason: 'Could not reach the application form' }
  }
  if (r.unanswered?.length) chrome.runtime.sendMessage({ type: 'saaf:questions', items: r.unanswered })
  return report(r.status, r.reason, r.coverage)
}

/** What happened when the person pressed "Apply on this page", in plain words. */
function renderApplyResult(root, out) {
  const el = root.getElementById('report')
  if (!out) { el.innerHTML = ''; return }
  const head = { submitted: '✓ Applied', unconfirmed: 'Check this tab', 'needs-you': 'Needs you' }[out.status] ?? out.status
  const cov = out.coverage ? `<div class="muted" style="margin-top:4px">${esc(out.coverage.percent)}% of required fields answered${out.coverage.missing?.length ? ` · missing: ${esc(out.coverage.missing.slice(0, 4).join('; '))}` : ''}</div>` : ''
  el.innerHTML = `<div class="box report"><b>${esc(head)}</b><div>${esc(out.reason)}</div>${cov}${out.status === 'submitted' ? '' : '<div class="muted" style="margin-top:6px">Nothing was submitted unless it says Applied. The page is yours — finish it by hand.</div>'}</div>`
}

/**
 * "Your Autofill information" — the pop-up Jobright opens from its panel (observed 2026-10-12): a section list on the left
 * (Personal, Education, Work Experience, Skill, Equal Employment, Preference, Sign-up Information), the section on the right,
 * an Update button below. Same layout here, Jobinko's colours and Jobinko's own code.
 *
 * Sign-up Information is fully live: registration email, password with a show/hide eye and a live five-rule list, and the
 * note that it stays in this browser's local storage (`chrome.storage.local`, never `sync`, never sent anywhere). The other
 * sections show what Jobinko will type, read-only — the profile on Jobinko is where they are edited.
 */
const AFM_TABS = [['personal', 'Personal'], ['education', 'Education'], ['work', 'Work Experience'], ['skill', 'Skill'], ['equal', 'Equal Employment'], ['pref', 'Preference'], ['signup', 'Sign-up Information']]
const AFM_FIELDS = [['First Name', (p) => (p.fullName || '').trim().split(/\s+/)[0]], ['Middle Name', (p) => p.middleName], ['Last Name', (p) => (p.fullName || '').trim().split(/\s+/).slice(1).join(' ')],
  ['Email Address', (p) => p.email], ['Phone Type', (p) => p.phoneType], ['Phone', (p) => p.phone], ['Address Line', (p) => p.address], ['Country/Region', (p) => p.country],
  ['State/Province', (p) => p.state], ['City', (p) => p.city], ['County', (p) => p.county], ['Postal Code', (p) => p.postalCode], ['LinkedIn URL', (p) => p.linkedin], ['Portfolio URL', (p) => p.portfolio]]
const AFM_EQUAL = [['Are you legally authorised to work in India?', 'authorisedToWork'], ['Will you now or in the future require sponsorship for an employment visa?', 'needsSponsorship'],
  ['What is your gender?', 'gender'], ['Do you have a disability?', 'disability'], ['Are you a veteran?', 'veteran'], ['How would you identify your race?', 'ethnicity'],
  ['Are you Hispanic or Latino?', 'hispanic'], ['Do you identify as LGBTQ+?', 'lgbtq'], ['How would you describe your sexual orientation?', 'orientation'], ['What are your pronouns?', 'pronouns']]

async function openAutofillModal(root, state, tab = 'personal') {
  const K = globalThis.SaafAccount
  root.getElementById('afm')?.remove()
  const ov = document.createElement('div')
  ov.id = 'afm'; ov.className = 'afm'
  ov.innerHTML = `<div class="afm-card" role="dialog" aria-label="Your Autofill information">
    <div class="afm-head"><h2>Your Autofill information</h2><button class="afm-x" aria-label="Close">✕</button></div>
    <div class="afm-banner"><span class="afm-i">i</span><div><b>Your autofill information stays in sync</b><span>It is read from your Jobinko profile, and answers you give on an application form are remembered for the next one.</span></div></div>
    <div class="afm-body"><nav class="afm-nav"></nav><div class="afm-pane"></div></div>
    <div class="afm-foot"><button class="afm-update" disabled>Update</button></div></div>`
  root.appendChild(ov)
  const $ = (sel) => ov.querySelector(sel)
  const nav = $('.afm-nav'); const pane = $('.afm-pane'); const update = $('.afm-update')
  let onUpdate = null
  const dirty = (on, fn) => { update.disabled = !on; if (fn) onUpdate = fn }
  const close = () => ov.remove()
  $('.afm-x').addEventListener('click', close)
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) close() })
  // While a save is under way the form is locked and the button says so: after a save the pane is redrawn from the account, and
  // anything typed in that window would be lost.
  update.addEventListener('click', async () => {
    if (update.disabled || !onUpdate) return
    const label = update.textContent
    update.disabled = true; update.textContent = 'Saving…'
    pane.style.pointerEvents = 'none'; pane.style.opacity = '0.6'
    try { await onUpdate() } finally {
      pane.style.pointerEvents = ''; pane.style.opacity = ''
      update.textContent = label
    }
  })

  const store = await chrome.storage.local.get(['profile', 'accountPassword', 'accountEmail', 'accountAutoAgree'])
  const profile = store.profile || {}
  const libraryData = async () => { const r = await chrome.runtime.sendMessage({ type: 'jx:library', view: 'profile' }).catch(() => null); return r?.ok ? r : null }
  const link = `<a href="${SITE}/profile" target="_blank" rel="noopener">Edit on Jobinko</a>`

  // The six editable tabs are drawn by profile-editor.js, from what the account holds (the "editor" view), and saved through the
  // same server actions the Profile page uses. `ed` is fetched once and again after every save, so positions stay right.
  let ed = null
  let current = null
  const loadEd = async () => { const r = await chrome.runtime.sendMessage({ type: 'jx:library', view: 'editor' }).catch(() => null); return r?.ok ? r : null }
  const write = (op, input, refresh = true) => chrome.runtime.sendMessage({ type: 'jx:profile-write', op, input, refresh }).then((r) => r || { ok: false, error: 'Could not reach Jobinko.' }).catch(() => ({ ok: false, error: 'Could not reach Jobinko.' }))
  const editorPane = async (key) => {
    pane.innerHTML = '<p class="afm-sub">Loading…</p>'
    if (!ed) ed = await loadEd()
    if (current !== key) return
    if (!ed) { pane.innerHTML = '<h3>Sign in</h3><p class="afm-sub">Sign in to Jobinko to see and edit this.</p>'; return }
    globalThis.SaafEditor.render(key, pane, {
      ed, profile, dirty, write,
      async saved(message) {
        await chrome.runtime.sendMessage({ type: 'jx:profile-refresh' }).catch(() => null)
        ed = await loadEd()
        Object.assign(profile, (await chrome.storage.local.get('profile')).profile || {})
        if (current !== key) return
        dirty(false)
        if (ed) globalThis.SaafEditor.render(key, pane, { ed, profile, dirty, write, saved: this.saved })
        const m = pane.querySelector('#ed-msg'); if (m && message) m.textContent = message
      },
    })
  }
  const panes = {
    personal: () => editorPane('personal'),
    education: () => editorPane('education'),
    work: () => editorPane('work'),
    skill: () => editorPane('skill'),
    equal: () => editorPane('equal'),
    pref: () => editorPane('pref'),
    signup() {
      pane.innerHTML = `<h3>Sign-up Information</h3>
        <p class="afm-sub"><b>Workday sites</b> require an account to apply. Save your credentials here and we’ll fill them in automatically.</p><hr>
        <label class="afm-l" for="su-email">Registration Email</label><input class="afm-in" id="su-email" type="email" autocomplete="off">
        <label class="afm-l" for="su-pw">Password</label>
        <div class="afm-pw"><input class="afm-in" id="su-pw" type="password" autocomplete="new-password" placeholder="Enter the password"><button type="button" class="afm-eye" aria-label="Show password">👁</button></div>
        <ul class="afm-rules"></ul><hr>
        <label class="afm-row"><input type="checkbox" id="su-agree"><span>Also tick the site’s “I agree to the terms” box for me when I create the account.<br><span class="muted">Off by default — otherwise I outline the box and you tick it. Never a marketing or newsletter box.</span></span></label>
        <div class="afm-green">🛡&nbsp;<span>Your password is stored in <b>your browser’s local storage</b>. Jobinko never saves or shares it with anyone.</span></div>
        <div class="afm-note"><a href="#" id="su-remove" ${store.accountPassword ? '' : 'hidden'}>Remove the saved password</a> <span id="su-msg"></span></div>`
      const email = pane.querySelector('#su-email'); const pw = pane.querySelector('#su-pw'); const agree = pane.querySelector('#su-agree'); const rules = pane.querySelector('.afm-rules'); const msg = pane.querySelector('#su-msg')
      const was = { email: store.accountEmail || profile.email || state.account?.email || '', pw: store.accountPassword || '', agree: store.accountAutoAgree === true }
      email.value = was.email; pw.value = was.pw; agree.checked = was.agree
      const draw = () => { rules.innerHTML = K.passwordRules(pw.value).map((r) => `<li class="${r.ok ? 'ok' : ''}"><i>✓</i>${esc(r.label)}</li>`).join('') }
      const check = () => {
        draw()
        const changed = email.value.trim() !== was.email || pw.value !== was.pw || agree.checked !== was.agree
        dirty(changed && !!email.value.trim() && !K.passwordProblem(pw.value), save)
        msg.textContent = changed && pw.value && K.passwordProblem(pw.value) ? K.passwordProblem(pw.value) : ''
      }
      const save = async () => {
        await chrome.storage.local.set({ accountPassword: pw.value, accountEmail: email.value.trim(), accountAutoAgree: agree.checked })
        was.email = email.value.trim(); was.pw = pw.value; was.agree = agree.checked
        store.accountPassword = pw.value
        msg.textContent = 'Saved.'; dirty(false)
        pane.querySelector('#su-remove').hidden = false
        state.afterAccountChange?.()
      }
      ;[email, pw].forEach((i) => i.addEventListener('input', check)); agree.addEventListener('change', check)
      pw.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !update.disabled) update.click() })
      pane.querySelector('.afm-eye').addEventListener('click', () => { pw.type = pw.type === 'password' ? 'text' : 'password' })
      pane.querySelector('#su-remove').addEventListener('click', async (e) => {
        e.preventDefault()
        await chrome.storage.local.remove(['accountPassword', 'accountEmail', 'accountAutoAgree'])
        store.accountPassword = ''
        was.pw = ''; pw.value = ''; agree.checked = false; was.agree = false; e.target.hidden = true
        msg.textContent = 'Removed.'; draw(); dirty(false)
        state.afterAccountChange?.()
      })
      draw(); dirty(false)
    },
  }
  const show = (key) => {
    nav.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.k === key))
    current = key; dirty(false, null); panes[key]()
  }
  nav.innerHTML = AFM_TABS.map(([k, l]) => `<button data-k="${k}">${esc(l)}</button>`).join('')
  nav.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) show(b.dataset.k) })
  show(tab)
}

/**
 * "Cover letter" — Generate / read / edit / use. The letter is written server-side from the posting and the person's own
 * profile (the website's writer, with its honesty check). It is only ever PROPOSED: nothing reaches a form until the person
 * presses "Use this letter", and the text box is theirs to rewrite. Stored per page, in this browser.
 */
const COVER_TONES = ['Professional', 'Direct', 'Consultative', 'High-Impact']
async function openCoverLetter(root, state, job, pk) {
  root.getElementById('afm')?.remove()
  const ov = document.createElement('div')
  ov.id = 'afm'; ov.className = 'afm'
  ov.innerHTML = `<div class="afm-card" role="dialog" aria-label="Cover letter" style="height:min(720px,92vh)">
    <div class="afm-head"><h2>Cover letter${job.company ? ` — ${esc(job.company)}` : ''}</h2><button class="afm-x" aria-label="Close">✕</button></div>
    <div class="afm-banner"><span class="afm-i">i</span><div><b>Written from your profile and this posting only</b><span>Every sentence is checked against your profile. Read it and change what you like — it goes into the application only after you press Use this letter.</span></div></div>
    <div class="afm-pane" style="display:flex;flex-direction:column;gap:12px">
      <div style="display:flex;gap:10px;align-items:center"><label class="afm-l" style="margin:0">Tone</label><select class="afm-in" id="cl-tone" style="width:auto">${COVER_TONES.map((t) => `<option>${t}</option>`).join('')}</select><button class="afm-ghost" id="cl-regen" style="padding:8px 16px;font-size:13px">↻ Write again</button><span class="muted" id="cl-note" style="flex:1"></span></div>
      <textarea class="afm-in" id="cl-text" style="flex:1;min-height:260px;resize:none;line-height:1.55" placeholder="Writing your letter…"></textarea>
    </div>
    <div class="afm-foot2"><button class="afm-ghost" id="cl-dl">⭳ Download</button><button class="afm-ghost" id="cl-rm">Remove</button><button class="afm-update" id="cl-use" disabled>Use this letter</button></div></div>`
  root.appendChild(ov)
  const $ = (sel) => ov.querySelector(sel)
  const close = () => ov.remove()
  $('.afm-x').addEventListener('click', close)
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) close() })
  const text = $('#cl-text'); const note = $('#cl-note'); const use = $('#cl-use')
  const { coverFor: all = {} } = await chrome.storage.local.get('coverFor')
  let saved = all[pk] || null
  // A [Bracketed blank] is something the person must fill — a letter that still has one is never put into an application.
  const blanks = () => [...new Set([...text.value.matchAll(/\[([^\]\n]{1,40})\]/g)].map((m) => m[1]))]
  const sync = () => {
    const open = blanks()
    use.disabled = !text.value.trim() || open.length > 0 || !!(saved && saved.text === text.value)
    if (open.length) note.textContent = `Fill in ${open.map((b) => `[${b}]`).join(', ')} first — then you can use the letter.`
  }
  const generate = async () => {
    text.disabled = true; $('#cl-regen').disabled = true; note.textContent = 'Writing — about 15 seconds…'; use.disabled = true
    const r = await chrome.runtime.sendMessage({ type: 'jx:cover-letter', jdText: job.description, jdTitle: job.title, company: job.company, tone: $('#cl-tone').value }).catch(() => null)
    text.disabled = false; $('#cl-regen').disabled = false
    if (r?.signedIn === false) { note.textContent = 'Sign in to Jobinko first.'; return }
    if (!r?.ok) { note.textContent = r?.error || 'Could not write it just now — you can write your own here.'; return }
    text.value = r.text
    note.textContent = r.dropped ? `A draft${r.providerLabel ? ` (${r.providerLabel})` : ''}. ${r.dropped} sentence${r.dropped === 1 ? '' : 's'} left out because your profile does not support ${r.dropped === 1 ? 'it' : 'them'}.` : `A draft${r.providerLabel ? ` (${r.providerLabel})` : ''} — edit freely.`
    sync()
  }
  text.addEventListener('input', sync)
  $('#cl-regen').addEventListener('click', generate)
  $('#cl-dl').addEventListener('click', async () => {
    if (!text.value.trim()) return
    const f = await chrome.runtime.sendMessage({ type: 'jx:cover-file', text: text.value, company: job.company }).catch(() => null)
    if (!f?.ok) { note.textContent = 'Could not make the file just now.'; return }
    const bytes = Uint8Array.from(atob(f.base64), (c) => c.charCodeAt(0))
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: f.type })); a.download = f.name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000)
  })
  $('#cl-rm').addEventListener('click', async () => {
    const { coverFor = {} } = await chrome.storage.local.get('coverFor'); delete coverFor[pk]
    await chrome.storage.local.set({ coverFor }); saved = null; text.value = ''; note.textContent = 'Removed — nothing will be filled.'; sync()
  })
  use.addEventListener('click', async () => {
    use.disabled = true; use.textContent = 'Saving…'
    const f = await chrome.runtime.sendMessage({ type: 'jx:cover-file', text: text.value, company: job.company }).catch(() => null)
    const { coverFor = {} } = await chrome.storage.local.get('coverFor')
    coverFor[pk] = { text: text.value, company: job.company || '', at: Date.now(), file: f?.ok ? { name: f.name, type: f.type, base64: f.base64 } : null }
    const keep = Object.entries(coverFor).sort((a, b) => (b[1].at || 0) - (a[1].at || 0)).slice(0, 20)
    await chrome.storage.local.set({ coverFor: Object.fromEntries(keep) })
    close()
  })
  if (saved) { text.value = saved.text; note.textContent = 'Your saved letter for this job.'; sync() } else generate()
}

/**
 * "View & Select Your Resume" — the same shape as Jobright's picker (observed 2026-10-12): the person's résumés as radio rows
 * with a PRIMARY badge, "Apply without resume", a preview on the right, Download Resume and Continue. Jobright's "Choose
 * version" row has no equivalent here (Jobinko keeps one résumé per label — a tailored one is its own row).
 */
async function openResumePicker(root, state) {
  root.getElementById('afm')?.remove()
  const ov = document.createElement('div')
  ov.id = 'afm'; ov.className = 'afm'
  ov.innerHTML = `<div class="afm-card" role="dialog" aria-label="View & Select Your Resume">
    <div class="afm-head"><h2>View &amp; Select Your Resume</h2><button class="afm-x" aria-label="Close">✕</button></div>
    <div class="afm-split"><div class="afm-list"><h4>Your Resume</h4><div id="rp-opts" class="muted">Loading…</div></div>
      <div class="afm-pane"><div class="afm-paper" id="rp-prev"></div></div></div>
    <div class="afm-foot2"><button class="afm-ghost" id="rp-dl">⭳ Download Resume</button><button class="afm-update" id="rp-go" disabled>Continue</button></div></div>`
  root.appendChild(ov)
  const $ = (sel) => ov.querySelector(sel)
  const close = () => ov.remove()
  $('.afm-x').addEventListener('click', close)
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) close() })
  const lib = await chrome.runtime.sendMessage({ type: 'jx:library', view: 'list' }).catch(() => null)
  if (!lib?.ok) { $('#rp-opts').textContent = lib?.signedIn === false ? 'Sign in to Jobinko to choose a résumé.' : 'Could not load your résumés.'; return }
  const { chosenResume } = await chrome.storage.local.get('chosenResume')
  const primary = lib.resumes.find((r) => r.isPrimary)?.id
  const start = chosenResume?.none ? 'none' : (chosenResume?.id && lib.resumes.some((r) => r.id === chosenResume.id) ? chosenResume.id : primary || lib.resumes[0]?.id || 'none')
  let sel = start
  const draw = () => {
    $('#rp-opts').innerHTML = lib.resumes.map((r) => `<div class="afm-opt ${sel === r.id ? 'on' : ''}" data-id="${esc(r.id)}"><input type="radio" ${sel === r.id ? 'checked' : ''} tabindex="-1"><span class="nm">${esc(r.label)}</span>${r.isPrimary ? '<span class="afm-badge">★ PRIMARY</span>' : ''}</div>`).join('')
      + `<div class="afm-opt ${sel === 'none' ? 'on' : ''}" data-id="none"><input type="radio" ${sel === 'none' ? 'checked' : ''} tabindex="-1"><span class="nm">Apply without resume</span></div>`
    $('#rp-go').disabled = sel === start
    $('#rp-dl').disabled = sel === 'none'
  }
  const preview = async () => {
    const box = $('#rp-prev')
    if (sel === 'none') { box.textContent = 'No résumé will be attached to this application.'; return }
    box.textContent = 'Loading…'
    const r = await chrome.runtime.sendMessage({ type: 'jx:library', view: 'preview', id: sel }).catch(() => null)
    if ($('#rp-prev') === box) box.textContent = r?.ok ? r.text : 'Could not load the preview.'
  }
  $('#rp-opts').addEventListener('click', (e) => { const o = e.target.closest('.afm-opt'); if (!o) return; sel = o.dataset.id; draw(); preview() })
  $('#rp-dl').addEventListener('click', async () => {
    const f = await chrome.runtime.sendMessage({ type: 'jx:resume-file', id: sel }).catch(() => null)
    if (!f?.ok) return
    const bytes = Uint8Array.from(atob(f.base64), (c) => c.charCodeAt(0))
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: f.type })); a.download = f.name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000)
  })
  $('#rp-go').addEventListener('click', async () => {
    $('#rp-go').disabled = true; $('#rp-go').textContent = 'Saving…'
    const picked = lib.resumes.find((r) => r.id === sel)
    await chrome.runtime.sendMessage(sel === 'none' ? { type: 'jx:resume-choose', none: true } : { type: 'jx:resume-choose', id: sel, updatedAt: picked?.updatedAt }).catch(() => null)
    await state.reconnect?.()
    close()
  })
  draw(); preview()
}

/**
 * ONE CLICK: fill the registration email and the saved password, tick the agreement box ONLY if the person switched that on,
 * and press the site's own Create account / Sign in button. A note is left in storage first, so the page that follows picks the
 * application up where this one left off (the same note Autofill uses). Returns a sentence for the panel.
 */
async function accountStep(state, kind) {
  const K = globalThis.SaafAccount
  const { accountPassword, accountEmail, accountAutoAgree, profile } = await chrome.storage.local.get(['accountPassword', 'accountEmail', 'accountAutoAgree', 'profile'])
  if (!accountPassword) return { done: false, needsPassword: true, text: 'Save your sign-up password first (Your autofill information → Sign-up Information).' }
  const email = accountEmail || profile?.email || state.account?.email
  if (!email) return { done: false, text: 'No email on file — sign in to Jobinko first.' }
  const e = K.fillEmail(document, email)
  K.fillPassword(document, accountPassword, kind)
  if (!e.hadEmailBox) return { done: false, text: 'Could not find the email box on this form — fill it yourself; the password is in.' }
  await new Promise((r) => setTimeout(r, 400)) // a beat for the page's own scripts to notice the new values
  await chrome.storage.local.set({ autofillPending: { at: Date.now() } })
  const out = K.proceed(document, kind, { tickAgreement: accountAutoAgree === true })
  if (out.waitingOn.length) return { done: false, text: 'Email and password are in. Tick the site’s agreement box (outlined) — that part is yours — then press the button again. (Sign-up Information can tick it for you.)' }
  if (!out.pressed) return { done: false, text: 'Email and password are in. I could not find the site’s own button — press it yourself.' }
  return { done: true, text: kind === 'signup' ? 'Account form sent. If the site asks you to verify your email, do that; Autofill carries on at the next page.' : 'Signing in… Autofill carries on at the next page.' }
}

/** The account wall: a sign-in or create-account form is on this page. */
async function renderWall(root, state) {
  const el = root.getElementById('wall')
  const K = globalThis.SaafAccount
  const kind = K?.kind(document)
  if (!kind) { el.innerHTML = ''; el.dataset.key = ''; return }
  const { accountPassword } = await chrome.storage.local.get('accountPassword')
  const has = typeof accountPassword === 'string' && accountPassword.length > 0
  const key = `${kind}:${has}`
  if (el.dataset.key === key) return
  el.dataset.key = key
  const title = kind === 'signup' ? 'This site wants you to create an account' : 'This site wants you to sign in'
  el.innerHTML = `<div class="box"><h3>${title}</h3>
    <div class="muted">${has ? 'Jobinko fills your email and your saved password, then presses the site’s own button — one click.' : 'Workday and similar sites need an account. Save your sign-up password once; after that it is one click.'}</div>
    <button class="btn primary" id="wallgo" style="margin-top:8px">${has ? (kind === 'signup' ? 'Create my account' : 'Sign in') : 'Add my sign-up password'}</button>
    <div class="note" id="wallnote"></div></div>`
  state.afterAccountChange = () => { el.dataset.key = ''; renderWall(root, state) }
  root.getElementById('wallgo').addEventListener('click', async () => {
    if (!has) { openAutofillModal(root, state, 'signup'); return }
    const r = await accountStep(state, kind)
    const n = root.getElementById('wallnote'); if (n) n.textContent = r.text
  })
}

/**
 * `run`: the page decides whether the panel shows — a posting with a description, a page with an application form, a page
 * the person just pressed Apply toward (the note in storage), the page after a Submit, or any page the toolbar icon forced.
 * Anything else stays quiet: an extension that paints on every page is one people uninstall.
 */
async function runPanel() {
  if (globalThis.__jxMounted) return
  const applied = await autoApplyIfAssigned()
  if (applied && !applied.here) return
  const job = globalThis.SaafExtract.extractJob(document, location)
  const { autofillPending: pending } = await chrome.storage.local.get('autofillPending')
  const pendingFresh = !!pending && Date.now() - pending.at < 90_000
  // A confirmation page is short: when the person applied from the panel, still show the panel with what happened.
  const noPosting = job.description.length < globalThis.SaafExtract.MIN_JD_CHARS
  const formHere = globalThis.SaafAutoApply.hasForm(document)
  if (noPosting && !applied && !globalThis.__jxForce && !pendingFresh && !formHere) return
  globalThis.__jxMounted = true
  globalThis.__jxPage = pageKey(location.href)
  const root = mount()
  const state = {
    signedIn: null, account: null, resumeFile: null, error: '',
    async reconnect() {
      state.signedIn = null; state.error = ''; renderAccount(root, state)
      const r = await chrome.runtime.sendMessage({ type: 'jx:connect', pageKey: pageKey(job.pageUrl) }).catch(() => null)
      state.signedIn = r?.signedIn ?? null
      state.account = r?.account ?? null
      state.resumeFile = r?.resumeFile ?? null
      state.drawTailored?.(r?.tailored ?? null)
      state.drawResume?.()
      state.error = r?.error || (r ? '' : 'Could not reach Jobinko.')
      renderAccount(root, state)
    },
  }
  renderAccount(root, state)
  mountActions(root, job, state)
  globalThis.__jxCurrent = { state, root }
  if (applied) renderApplyResult(root, applied) // the page reloaded after Submit: show what the employer said
  // Connect first so the score below uses the account's current résumé.
  await state.reconnect()
  // The person pressed Autofill on the posting and the form opened here (the same tab, or a new one): carry on, no click needed.
  if (pendingFresh && !applied) {
    if (await globalThis.SaafAutoApply.waitForForm(document, 8000)) {
      await chrome.storage.local.remove('autofillPending')
      state.autofill?.()
    }
  }
  // A full page load in the middle of an application (not a single-page step): "Autofill After Page Turn: Automatically".
  else if (!applied) {
    const { jxSettings = {}, appSession } = await chrome.storage.local.get(['jxSettings', 'appSession'])
    if (jxSettings.pageTurn !== 'manual' && appSession?.host === location.host && Date.now() - appSession.at < 30 * 60_000 && (formHere || globalThis.SaafAccount?.kind(document))) {
      if (await globalThis.SaafAutoApply.waitForForm(document, 8000) || globalThis.SaafAccount?.kind(document)) state.autofill?.()
    }
  }
  if (noPosting) { root.getElementById('match').innerHTML = ''; return }
  chrome.runtime.sendMessage(
    { type: 'saaf:score', jdText: job.description, jdTitle: job.title, jdLocation: job.location },
    (data) => renderMatch(root, job, data),
  )
}

/** Take the panel down completely — its DOM, its listeners, the room it made on the page — so a fresh one can be built. */
function teardownPanel() {
  try { globalThis.__jxCurrent?.state.stop?.() } catch { /* already gone */ }
  document.getElementById('saaf-overlay-host')?.remove()
  document.documentElement.style.marginLeft = ''
  document.documentElement.style.marginRight = ''
  globalThis.__jxPanelToggle = null
  globalThis.__jxCurrent = null
  globalThis.__jxMounted = false
}

/**
 * ⚠️ THE PAGE CHANGES UNDER THE PANEL, and the panel must follow. A job site is mostly one long-lived page: the address changes,
 * the content is swapped, and the script that opened the panel never runs again. The panel used to read the page once, when it
 * opened (plus five minutes of watching), so after a move to a different application it kept the OLD job and — worst — the old
 * "this site wants you to create an account" box. Now, for as long as the tab is open:
 *   - the ADDRESS (without ?query and #hash) changing rebuilds the panel for the new page — unless a fill or a submit is under
 *     way, in which case it waits for that to finish;
 *   - a page with NO panel is looked at again when its address changes or an application form appears, so landing on an
 *     application inside a single-page site shows the panel without a reload.
 * The check is a string compare once a second plus the browser's own navigation events; the heavier read only runs on a change.
 */
if (!globalThis.__jxWatching) {
  globalThis.__jxWatching = true
  let lastKey = pageKey(location.href)
  let lastForm = false
  let beat = 0
  const tick = () => {
    if (document.visibilityState === 'hidden') return
    const cur = globalThis.__jxCurrent
    if (cur?.state.running || cur?.state.submitting) return
    const key = pageKey(location.href)
    if (globalThis.__jxMounted) {
      if (key !== globalThis.__jxPage) { teardownPanel(); runPanel() }
      else if (++beat % 2 === 0) cur?.state.reassess?.() // every other second, whether or not the page announced a change
    } else {
      const form = globalThis.SaafAutoApply.hasForm(document)
      if (key !== lastKey || (form && !lastForm)) runPanel()
      lastForm = form
    }
    lastKey = key
  }
  setInterval(tick, 1000)
  window.addEventListener('popstate', tick)
  window.addEventListener('hashchange', tick)
  globalThis.navigation?.addEventListener?.('navigatesuccess', () => setTimeout(tick, 200))
}

runPanel()
